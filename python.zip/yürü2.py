import pygame,sys,os,random
pygame.init()
width=1200
height=675
window_size=(width,height)
window=pygame.display.set_mode(window_size)
clock=pygame.time.Clock()
fps=60

sag=[]
sol=[]
yukari=[]
asagi=[]

klasor=os.path.dirname(__file__)
resimler=os.path.join(klasor,"resimler2")

bg=pygame.image.load(os.path.join(resimler,"bg3.png"))

all_sprite=pygame.sprite.Group()

for i in range (1,6):
    sag.append("r{}.png".format(i))
    sol.append("l{}.png".format(i))
    yukari.append("u{}.png".format(i))
    asagi.append("d{}.png".format(i))


class Yuru(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.rsayac=0
        self.usayac = 0
        self.lsayac = 0
        self.dsayac = 0
        self.x=400
        self.y=300
        self.image=pygame.image.load(os.path.join(resimler,sag[self.rsayac])).convert()
        self.image.set_colorkey((255,255,255))
        self.rect=self.image.get_rect()
        self.rect.center=(self.x,self.y)

        self.delay=pygame.time.get_ticks()

    def update(self):
        a=pygame.time.get_ticks()
        if right_key == 1:
            self.rsayac +=1
            if self.rsayac == 5:
                self.rsayac = 0

            if a - self.delay > 35:
                self.delay = a
                self.image = pygame.image.load(os.path.join(resimler, sag[self.rsayac])).convert()
                self.image.set_colorkey((255, 255, 255))
                self.rect = self.image.get_rect()
                self.x +=10
                self.y += 5
                self.rect.center = (self.x, self.y)

        if left_key == 1:
            if self.lsayac ==5:
                self.lsayac=0

            if a - self.delay > 55:
                self.delay = a
                self.image = pygame.image.load(os.path.join(resimler, sol[self.lsayac])).convert()
                self.image.set_colorkey((255, 255, 255))
                self.rect = self.image.get_rect()
                self.x -= 10
                self.y -=5
                self.rect.center = (self.x, self.y)

            self.lsayac +=1

        if up_key ==1:
            if self.usayac == 5:
                self.usayac = 0

            if a - self.delay > 55:
                self.delay=a
                self.image = pygame.image.load(os.path.join(resimler, yukari[self.usayac])).convert()
                self.image.set_colorkey((255, 255, 255))
                self.rect = self.image.get_rect()
                self.y -= 5
                self.x +=10
                self.rect.center = (self.x, self.y)

            self.usayac +=1

        if down_key ==1:
            if self.dsayac == 5:
                self.dsayac = 0

            if a - self.delay > 55:
                self.delay=a
                self.image = pygame.image.load(os.path.join(resimler, asagi[self.dsayac])).convert()
                self.image.set_colorkey((255, 255, 255))
                self.rect = self.image.get_rect()
                self.y += 5
                self.x -=10
                self.rect.center = (self.x, self.y)

            self.dsayac +=1



        if self.x > width:
            self.x=0

        if self.x < 0:
            self.x = width-self.rect.size[0]

        if self.y > height:
            self.y = 0

        if self.y < 0 :
            self.y = height-self.rect.size[1]



yuru=Yuru()
all_sprite.add(yuru)

while True:
    clock.tick(fps)
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            sys.exit()

    keys=pygame.key.get_pressed()
    right_key=keys[pygame.K_RIGHT]
    left_key=keys[pygame.K_LEFT]
    up_key=keys[pygame.K_UP]
    down_key=keys[pygame.K_DOWN]


    window.fill((0,0,0))
    window.blit(bg,(bg.get_rect()))
    all_sprite.draw(window)
    all_sprite.update()

    pygame.display.update()